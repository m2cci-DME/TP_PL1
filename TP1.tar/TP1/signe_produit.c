
#include <stdio.h>

int main() {

  int x ;
  int y ;

  /* lecture au clavier des entiers x et y */

  printf("entrez un entier relatif au clavier\n") ;
  scanf ("%d", &x) ;
  printf("entrez un deuxieme entier relatif au clavier\n") ;
  scanf ("%d", &y) ;

  /* calcul du signe du produit x*y sans calculer ce produit */

  if (      ) {
     printf("le produit de %d et %d est strictement positif\n", x, y) ;
  } else if (      ) {
   
  } else {

  }; 
	

  return 0 ;
}
